package spr_b4;

public class _41_Wraparound1 {

	public static void main(String[] args) {

		int[] arr = { 1,2,3,4 }; 
		int num = 10;
		
		// the first number to be printed from arr is 1.
		// the next number to be printed is 2.
		// keep on printing the next number, until you reach 4.
		// then the next number to be printed is back to 1(beginning)
		// always start with the first number,
		// keep this up num times.
		// i.e. 1 2 3 4 1 2 3 4 1 2 
		

		

	}

}
