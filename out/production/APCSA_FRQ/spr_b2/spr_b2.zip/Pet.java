package spr_b2;

public class Pet {
	private String myName;
	
	public Pet(String name) {
		myName = name;
	}

	public String getName() {
		return myName;
	}

	public String speak() {
		
		return "";
	}
	
	// added to enable Main
	public Pet() {
	}
}
