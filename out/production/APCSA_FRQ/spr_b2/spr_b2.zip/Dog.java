package spr_b2;

public class Dog extends Pet {

	public Dog(String name) {
		// implementation not shown
	}

	public String speak() {
		// implementation not shown 
		return "";
	}

}
