package spr_b2;

// (b)
public class LoudDog {


}
