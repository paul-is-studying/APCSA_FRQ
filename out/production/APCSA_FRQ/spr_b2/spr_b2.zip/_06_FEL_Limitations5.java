package spr_b2;

import java.util.Arrays;

public class _06_FEL_Limitations5 {

	public static void main(String[] args) {

		int[] arr = { 7, 6, 4, 8, 3, 9 };
		
		System.out.println(Arrays.toString(arr));
		
		// find the minimum value of arr and its index 
		System.out.println("minimum : " + min(arr));
		System.out.println("min index : " + minIndex(arr));
		
	}
	
	// use a for-each loop!!
	private static int min(int[] arr) {

		return 0;
	}
	
	// use a for-each loop!!
	private static int minIndex(int[] arr) {

		return 0;
	}
	
}
