package spr_b2;

import java.util.Arrays;

public class _03_FEL_Limitations2 {

	public static void main(String[] args) {

		int[] arr = { 1, 6, 2, 8, 3, 9 };
		
		System.out.println(Arrays.toString(arr));
		
		// use this method to print the first half of arr.
		// i.e. : 1, 6, 2
		printFirstHalf(arr);
		
		
	}
	
	// use a for-each loop!!
	private static void printFirstHalf(int[] arr) {

	}

}
