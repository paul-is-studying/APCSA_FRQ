package spr_b2;

import java.util.ArrayList;

public class _33_CountUnique {

	public static void main(String[] args) {

		ArrayList<String> list = new ArrayList<String>();
		list.add("cat");
		list.add("dog");
		list.add("cat");
		list.add("cat");
		list.add("rat");
		list.add("cat");
		list.add("dog");
		list.add("man");
		
		// how many unique animals are there in list?
		int num = 0;
		
		
		System.out.println("num of uniques: "+num);

		
	}

	
}
