package spr_b2;

// (a)
public class Cat {

}
