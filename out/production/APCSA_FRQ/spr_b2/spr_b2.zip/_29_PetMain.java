package spr_b2;

import java.util.ArrayList;

// requires: Pet.java, Cat.java, Dog.java, LoudDog.java, Kennel.java
public class _29_PetMain {

	public static void main(String[] args) {
		/*
		// (a)
		System.out.println("\n===(a)========================");
		Cat c = new Cat("Garfield");
		System.out.println(c.getName()+": "+c.speak());
		
		// (b)
		System.out.println("\n===(b)========================");
		LoudDog d = new LoudDog("Collie");
		System.out.println(d.getName()+": "+d.speak());
		
		// (c)
		System.out.println("\n===(c)========================");
		ArrayList<Pet> list = new ArrayList<Pet>();
		list.add(new Dog("Badoogie"));
		list.add(c);
		list.add(d);
		Kennel k = new Kennel(list);
		k.allSpeak();
		*/
	}

}
