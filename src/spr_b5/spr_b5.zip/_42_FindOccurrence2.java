package spr_b5;

public class _42_FindOccurrence2 {

	public static void main(String[] args) {
		
		String str = "ababbabbbab";
		
		// find the index of the seconnd occurrence of 'a' in str
		
		int index1 = 0;
		int index2 = 0;
		

		
		System.out.println(index1); // 0
		System.out.println(index2); // 0
		
		
	}

}
