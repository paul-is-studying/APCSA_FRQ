package spr_b5;

public class Phrase {
	private String currentPhrase;
	
	// constructor
	public Phrase(String p) {
		currentPhrase = p;
	}
	
	// a bit patchwork.. see if you can improve this.
	public int findNthOccurrence(String str, int n) {
		// implementation not shown

		return 0;
	}

	
	public void replaceNthOccurrence(String str, int n, String repl) {
		// to be implemented in part (a)

	}

	public int findLastOccurrence(String str) {
		// to be implemented in part (b)

		return 0;
	}
	
	public String toString() {
		return currentPhrase;
	}
	
}
