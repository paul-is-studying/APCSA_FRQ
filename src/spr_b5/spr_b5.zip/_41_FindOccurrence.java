package spr_b5;

public class _41_FindOccurrence {

	public static void main(String[] args) {
		
		String str = "ababbabbbab";
		
		// find the index of the first occurrence of 'a' in str
		
		int index = 0;
		
		index = str.indexOf('a');
		
		System.out.println(index); // 0
		
	}

}
