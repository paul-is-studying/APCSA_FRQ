package spr_b5;

public class _03_StaticVariableUsage {

	public static void main(String[] args) {
		

		
	}
	
	public static class Account {
		private static int ref = 0; // change this to non-static & see what happens
		private int id;
		private String name;
		public Account(String n) {
			name = n;
			ref++;
			id = ref;
		}
		public String toString() {return name+"("+id+")";}
	}

}
