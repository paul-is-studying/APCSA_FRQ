package spr_b5;

public class _43_LastOccurrence {

	public static void main(String[] args) {
		
		String str = "ababbabbbab";
		
		// find the index of the last occurrence of 'a' in str
		
		// expected: 9 


		
		
	}

}
